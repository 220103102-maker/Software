public interface CoolingStrategy { double getTargetTemp(int occupants); }
