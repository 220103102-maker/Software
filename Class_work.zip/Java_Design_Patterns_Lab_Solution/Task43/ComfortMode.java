public class ComfortMode implements CoolingStrategy { public double getTargetTemp(int occupants){return occupants>=1?22.0:28.0;} }
