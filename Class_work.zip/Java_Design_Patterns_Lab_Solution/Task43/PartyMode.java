public class PartyMode implements CoolingStrategy { public double getTargetTemp(int occupants){return Math.max(18.0,22.0-occupants*0.5);} }
