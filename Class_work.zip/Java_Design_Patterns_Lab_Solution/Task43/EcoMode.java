public class EcoMode implements CoolingStrategy { public double getTargetTemp(int occupants){return 26.0;} }
