public class BaseInvoice implements Invoice { private final double subtotal; public BaseInvoice(double subtotal){this.subtotal=subtotal;} public double getTotal(){return subtotal;} }
