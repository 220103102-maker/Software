public class TaxDecorator implements Invoice { private final Invoice inner; public TaxDecorator(Invoice i){inner=i;} public double getTotal(){return inner.getTotal()*1.18;} }
