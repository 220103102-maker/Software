public class PackagingFeeDecorator implements Invoice { private final Invoice inner; public PackagingFeeDecorator(Invoice i){inner=i;} public double getTotal(){return inner.getTotal()+45.0;} }
