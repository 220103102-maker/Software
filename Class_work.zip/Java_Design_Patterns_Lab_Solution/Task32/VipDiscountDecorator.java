public class VipDiscountDecorator implements Invoice { private final Invoice inner; public VipDiscountDecorator(Invoice i){inner=i;} public double getTotal(){return inner.getTotal()*0.90;} }
