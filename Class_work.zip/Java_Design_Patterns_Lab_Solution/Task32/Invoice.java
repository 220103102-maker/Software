public interface Invoice { double getTotal(); }
