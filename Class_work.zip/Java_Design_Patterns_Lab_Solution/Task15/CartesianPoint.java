public interface CartesianPoint { double getX(); double getY(); }
