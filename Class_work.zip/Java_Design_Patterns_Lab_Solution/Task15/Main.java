public class Main { public static void main(String[] args){CartesianPoint p=new PolarToCartesianAdapter(new PolarPoint(5,Math.PI/4));System.out.printf("x=%.2f, y=%.2f%n",p.getX(),p.getY());} }
