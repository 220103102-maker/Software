public class ByteFileStat { private final long bytes; public ByteFileStat(long bytes){this.bytes=bytes;} public long getBytes(){return bytes;} }
