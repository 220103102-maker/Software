public class Main { public static void main(String[] args){System.out.println(new FileSizeAdapter(new ByteFileStat(5242880L)).getSizeInMB()+" MB");} }
