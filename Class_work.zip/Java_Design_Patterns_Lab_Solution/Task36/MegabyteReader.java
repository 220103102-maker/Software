public interface MegabyteReader { double getSizeInMB(); }
