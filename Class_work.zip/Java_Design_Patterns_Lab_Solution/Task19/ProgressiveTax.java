public class ProgressiveTax implements TaxStrategy { public double calculateTax(double income){return Math.min(income,100000.0)*0.05+Math.max(0.0,income-100000.0)*0.20;} }
