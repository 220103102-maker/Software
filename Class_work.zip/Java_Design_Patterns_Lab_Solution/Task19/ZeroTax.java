public class ZeroTax implements TaxStrategy { public double calculateTax(double income){return 0.0;} }
