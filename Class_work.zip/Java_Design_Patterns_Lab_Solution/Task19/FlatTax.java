public class FlatTax implements TaxStrategy { public double calculateTax(double income){return income*0.10;} }
