public class Main { public static void main(String[] args){new LoggerAdapter(new ConsoleWriter()).log("info","Application started");} }
