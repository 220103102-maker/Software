public interface AppLogger { void log(String level,String message); }
