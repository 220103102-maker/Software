public class ConsoleWriter { public void writeLine(String fullText){System.out.println(fullText);} }
