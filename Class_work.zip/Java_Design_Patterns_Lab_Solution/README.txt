JAVA DESIGN PATTERNS LAB — SOLUTIONS FOR TASKS 1–50

Structure:
- Task01 through Task50 are separate self-contained folders.
- Each folder contains separate .java files for its interface, concrete classes/adapters/decorators, and Main.java.
- Open one task folder at a time in IntelliJ IDEA and run Main.java.
- The folders intentionally use the default package; do not combine all task folders into one source folder because some tasks reuse names such as Main, TaxStrategy, and HeaderDecorator.
- Requires a Java JDK (Java 17 or newer recommended).

The code demonstrates the behavior requested in the supplied lab PDF. Check your instructor's submission requirements before submitting.
