public class CoreHandler implements RequestHandler { public String handle(String request){return "200 OK: "+request;} }
