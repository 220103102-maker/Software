public interface Car { String getConfiguration(); double getPrice(); }
