public class BaseSedan implements Car { public String getConfiguration(){return "Standard Sedan";} public double getPrice(){return 15000.0;} }
