public interface AudioSignal { double[] process(double[] samples); }
