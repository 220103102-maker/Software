public class MicrosecondClock { private final long micros; public MicrosecondClock(long micros){this.micros=micros;} public long readMicroseconds(){return micros;} }
