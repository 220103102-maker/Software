public class Main { public static void main(String[] args){System.out.println(new ClockAdapter(new MicrosecondClock(1234567L)).getElapsedMillis()+" ms");} }
