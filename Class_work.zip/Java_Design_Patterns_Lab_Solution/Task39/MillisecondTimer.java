public interface MillisecondTimer { long getElapsedMillis(); }
