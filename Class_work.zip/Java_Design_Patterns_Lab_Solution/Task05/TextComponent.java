public interface TextComponent { String format(String input); }
