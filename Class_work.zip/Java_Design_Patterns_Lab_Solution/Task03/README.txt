Task 3: Java Design Patterns Lab

This folder contains separate .java files for this task.
Run Main.java from this folder in IntelliJ IDEA. All files are in the default package.
The implementation follows the task description in the supplied PDF.
