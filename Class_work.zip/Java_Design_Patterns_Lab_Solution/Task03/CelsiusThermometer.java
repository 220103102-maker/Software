public interface CelsiusThermometer { double getTemperatureC(); }
