public class EmailNotifier implements Notifier { public String send(String msg){return "EMAIL: "+msg;} }
