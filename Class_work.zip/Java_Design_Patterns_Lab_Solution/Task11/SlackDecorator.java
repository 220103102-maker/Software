public class SlackDecorator implements Notifier { private final Notifier inner; public SlackDecorator(Notifier n){inner=n;} public String send(String msg){return inner.send(msg)+" | SLACK: "+msg;} }
