public class SMSDecorator implements Notifier { private final Notifier inner; public SMSDecorator(Notifier n){inner=n;} public String send(String msg){return inner.send(msg)+" | SMS: "+msg;} }
