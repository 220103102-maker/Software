public interface Notifier { String send(String msg); }
