public class Main { public static void main(String[] args){MetricSpeedometer s=new SpeedAdapter(new ImperialSpeedometer(60));System.out.printf("%.2f km/h%n",s.getSpeedKmh());} }
