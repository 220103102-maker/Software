public class ImperialSpeedometer { private final double mph; public ImperialSpeedometer(double mph){this.mph=mph;} public double getSpeedMph(){return mph;} }
