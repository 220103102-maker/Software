public interface MetricSpeedometer { double getSpeedKmh(); }
