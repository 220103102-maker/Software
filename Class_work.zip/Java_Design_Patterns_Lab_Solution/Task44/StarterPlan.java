public class StarterPlan implements StoragePlan { public int getStorageGB(){return 50;} public double getCost(){return 5.0;} }
