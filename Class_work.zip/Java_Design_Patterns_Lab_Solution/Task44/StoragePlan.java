public interface StoragePlan { int getStorageGB(); double getCost(); }
