public class CyclingStrategy implements RouteStrategy { public int estimateMinutes(int d){return d*4;} }
