public class WalkingStrategy implements RouteStrategy { public int estimateMinutes(int d){return d*12;} }
