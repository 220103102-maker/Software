public class DrivingStrategy implements RouteStrategy { public int estimateMinutes(int d){return d+10;} }
