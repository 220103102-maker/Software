public interface RouteStrategy { int estimateMinutes(int distanceKm); }
