public class VowelStripStrategy implements CompressionStrategy { public String compress(String s){return s.replaceAll("(?i)[aeiou]","")+".vzp";} }
