public class HyphenPackStrategy implements CompressionStrategy { public String compress(String s){return s.replace(' ','-')+".hpk";} }
