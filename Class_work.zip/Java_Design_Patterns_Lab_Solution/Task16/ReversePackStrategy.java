public class ReversePackStrategy implements CompressionStrategy { public String compress(String s){return new StringBuilder(s).reverse().toString()+".rev";} }
