public interface CompressionStrategy { String compress(String rawData); }
