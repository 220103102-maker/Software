public class PromoInterest implements InterestStrategy { public double computeInterest(double p,int y){return y==1?0.0:p*0.12*y;} }
