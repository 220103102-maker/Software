public interface InterestStrategy { double computeInterest(double principal,int years); }
