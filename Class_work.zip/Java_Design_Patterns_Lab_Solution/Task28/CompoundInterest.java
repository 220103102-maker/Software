public class CompoundInterest implements InterestStrategy { public double computeInterest(double p,int y){return p*Math.pow(1.08,y)-p;} }
