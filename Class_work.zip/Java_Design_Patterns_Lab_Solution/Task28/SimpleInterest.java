public class SimpleInterest implements InterestStrategy { public double computeInterest(double p,int y){return p*0.08*y;} }
