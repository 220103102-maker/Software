public interface SchedulerStrategy { int selectNextIndex(int[] burstTimes); }
