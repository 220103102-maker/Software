public class FirstComeFirstServed implements SchedulerStrategy { public int selectNextIndex(int[] a){return a.length==0?-1:0;} }
