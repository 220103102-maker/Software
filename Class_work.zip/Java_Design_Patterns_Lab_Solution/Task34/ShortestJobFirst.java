public class ShortestJobFirst implements SchedulerStrategy { public int selectNextIndex(int[] a){if(a.length==0)return -1;int m=0;for(int i=1;i<a.length;i++)if(a[i]<a[m])m=i;return m;} }
