public class VegPattyBurger implements Burger { public String getIngredients(){return "Bun + Veg Patty";} public double getPrice(){return 80.0;} }
