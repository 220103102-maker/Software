public interface Burger { String getIngredients(); double getPrice(); }
