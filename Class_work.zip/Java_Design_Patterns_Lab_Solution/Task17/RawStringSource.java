public class RawStringSource implements DataSource { public String readData(){return "confidential_payload";} }
