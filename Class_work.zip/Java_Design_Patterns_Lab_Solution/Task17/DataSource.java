public interface DataSource { String readData(); }
