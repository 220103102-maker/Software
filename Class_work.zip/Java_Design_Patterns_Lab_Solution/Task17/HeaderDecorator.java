public class HeaderDecorator implements DataSource { private final DataSource inner; public HeaderDecorator(DataSource d){inner=d;} public String readData(){return "SEC_HEADER:"+inner.readData();} }
