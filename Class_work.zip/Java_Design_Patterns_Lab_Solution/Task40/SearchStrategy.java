public interface SearchStrategy { int findIndex(int[] sortedArr,int target); }
