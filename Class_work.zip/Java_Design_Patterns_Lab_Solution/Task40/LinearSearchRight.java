public class LinearSearchRight implements SearchStrategy { public int findIndex(int[] a,int t){for(int i=a.length-1;i>=0;i--)if(a[i]==t)return i;return -1;} }
