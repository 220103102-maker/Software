public class LinearSearchLeft implements SearchStrategy { public int findIndex(int[] a,int t){for(int i=0;i<a.length;i++)if(a[i]==t)return i;return -1;} }
