public class ExpressShipping implements ShippingStrategy { public double calculate(double w,double d){return w*5.0+d*1.2+50.0;} }
