public class DroneShipping implements ShippingStrategy { public double calculate(double w,double d){return w<5.0?100.0:-1.0;} }
