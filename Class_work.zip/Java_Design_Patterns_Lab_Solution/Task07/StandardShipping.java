public class StandardShipping implements ShippingStrategy { public double calculate(double w,double d){return w*2.0+d*0.5;} }
