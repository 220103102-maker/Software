public interface ShippingStrategy { double calculate(double weightKg,double distanceKm); }
