public class BasicTunic implements CharacterDefense { public int getArmorRating(){return 10;} }
