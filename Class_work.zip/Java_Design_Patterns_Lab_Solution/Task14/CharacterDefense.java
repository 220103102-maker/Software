public interface CharacterDefense { int getArmorRating(); }
