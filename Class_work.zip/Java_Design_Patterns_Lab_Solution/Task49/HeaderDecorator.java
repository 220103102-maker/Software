public class HeaderDecorator implements Receipt { private final Receipt inner; public HeaderDecorator(Receipt r){inner=r;} public String render(){return "=== STORE ===\n"+inner.render();} }
