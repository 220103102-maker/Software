public class LocalTax implements TaxStrategy { public double calculateTax(double price){return price*0.05;} }
