public interface Receipt { String render(); }
