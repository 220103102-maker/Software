public class BasicGymAccess implements Membership { public String getPerks(){return "Gym Floor";} public double getMonthlyFee(){return 1000.0;} }
