public interface Membership { String getPerks(); double getMonthlyFee(); }
