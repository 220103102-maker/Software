public interface StaffMember { String getFullName(); double getAnnualSalary(); }
