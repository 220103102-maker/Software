public class MagicAttack implements AttackStrategy { public int computeDamage(int s){return s*3-10;} }
