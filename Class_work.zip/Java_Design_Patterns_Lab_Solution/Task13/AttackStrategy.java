public interface AttackStrategy { int computeDamage(int baseStrength); }
