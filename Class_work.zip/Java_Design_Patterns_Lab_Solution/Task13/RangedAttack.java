public class RangedAttack implements AttackStrategy { public int computeDamage(int s){return s+15;} }
