public class MeleeAttack implements AttackStrategy { public int computeDamage(int s){return s*2;} }
