public interface PercentageBattery { int getBatteryPercent(); }
