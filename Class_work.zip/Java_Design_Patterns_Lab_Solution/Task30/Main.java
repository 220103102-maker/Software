public class Main { public static void main(String[] args){System.out.println(new BatteryAdapter(new VoltageBattery(3.6)).getBatteryPercent()+"%");} }
