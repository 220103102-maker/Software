public class VoltageBattery { private final double voltage; public VoltageBattery(double v){voltage=v;} public double getVoltage(){return voltage;} }
