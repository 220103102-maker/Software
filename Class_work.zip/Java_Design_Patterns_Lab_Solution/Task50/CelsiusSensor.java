public interface CelsiusSensor { double getCelsius(); }
