public class HeatwaveAlert implements AlertStrategy { public boolean isTriggered(double tempC){return tempC>40.0;} }
