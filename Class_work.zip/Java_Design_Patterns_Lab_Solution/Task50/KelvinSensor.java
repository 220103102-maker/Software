public class KelvinSensor { private final double kelvin; public KelvinSensor(double kelvin){this.kelvin=kelvin;} public double readKelvin(){return kelvin;} }
