public class FrostAlert implements AlertStrategy { public boolean isTriggered(double tempC){return tempC<0.0;} }
