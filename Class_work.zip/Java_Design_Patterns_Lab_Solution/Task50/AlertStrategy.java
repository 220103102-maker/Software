public interface AlertStrategy { boolean isTriggered(double tempC); }
