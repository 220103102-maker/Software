public class Espresso implements Beverage { public String getDescription() { return "Espresso"; } public double getCost() { return 100.0; } }
