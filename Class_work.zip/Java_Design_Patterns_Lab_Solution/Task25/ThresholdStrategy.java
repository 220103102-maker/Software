public class ThresholdStrategy implements PixelFilterStrategy { public int[] applyFilter(int[] p){int[] r=p.clone();for(int i=0;i<r.length;i++)r[i]=r[i]>=128?255:0;return r;} }
