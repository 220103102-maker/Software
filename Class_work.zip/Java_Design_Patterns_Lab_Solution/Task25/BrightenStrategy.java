public class BrightenStrategy implements PixelFilterStrategy { public int[] applyFilter(int[] p){int[] r=p.clone();for(int i=0;i<r.length;i++)r[i]=Math.min(255,r[i]+30);return r;} }
