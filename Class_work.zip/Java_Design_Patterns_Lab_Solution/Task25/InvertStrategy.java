public class InvertStrategy implements PixelFilterStrategy { public int[] applyFilter(int[] p){int[] r=p.clone();for(int i=0;i<r.length;i++)r[i]=255-r[i];return r;} }
