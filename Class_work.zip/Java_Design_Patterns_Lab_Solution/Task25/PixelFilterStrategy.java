public interface PixelFilterStrategy { int[] applyFilter(int[] pixels); }
