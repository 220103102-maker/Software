public class Main { public static void main(String[] args){SimpleStack s=new StackAdapter(new IntArrayBuffer());s.push(10);s.push(20);System.out.println(s.pop());System.out.println(s.pop());} }
