public interface SimpleStack { void push(int val); int pop(); }
