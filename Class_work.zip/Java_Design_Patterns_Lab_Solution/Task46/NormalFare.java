public class NormalFare implements FareStrategy { public double computeFare(double km){return 50.0+km*12.0;} }
