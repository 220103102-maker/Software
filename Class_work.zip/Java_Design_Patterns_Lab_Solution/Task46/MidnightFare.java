public class MidnightFare implements FareStrategy { public double computeFare(double km){return 80.0+km*15.0;} }
