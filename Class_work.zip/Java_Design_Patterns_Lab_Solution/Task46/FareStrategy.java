public interface FareStrategy { double computeFare(double km); }
