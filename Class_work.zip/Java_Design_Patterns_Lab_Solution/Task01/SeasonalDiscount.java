public class SeasonalDiscount implements DiscountStrategy { public double applyDiscount(double price) { return price * (price > 500.0 ? 0.75 : 0.95); } }
