public class FlatDiscount implements DiscountStrategy { public double applyDiscount(double price) { return Math.max(0.0, price - 50.0); } }
