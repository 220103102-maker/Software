public class PercentageDiscount implements DiscountStrategy { public double applyDiscount(double price) { return price * 0.85; } }
