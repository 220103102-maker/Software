public interface Dessert { String describe(); int getCalories(); }
