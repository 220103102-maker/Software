public class VanillaScoop implements Dessert { public String describe(){return "Vanilla Scoop";} public int getCalories(){return 150;} }
