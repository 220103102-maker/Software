public class ArrayDataStore { private final String[] words; public ArrayDataStore(String[] words){this.words=words;} public String[] fetchWords(){return words;} }
