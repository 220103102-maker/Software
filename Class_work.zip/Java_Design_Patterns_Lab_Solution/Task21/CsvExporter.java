public interface CsvExporter { String exportCsv(); }
