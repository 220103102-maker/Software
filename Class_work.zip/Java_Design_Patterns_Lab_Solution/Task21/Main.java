public class Main { public static void main(String[] args){CsvExporter c=new ArrayToCsvAdapter(new ArrayDataStore(new String[]{"red","green","blue"}));System.out.println(c.exportCsv());} }
