public class SimpleText implements FormattedText { private final String text; public SimpleText(String text){this.text=text;} public String render(){return text;} }
