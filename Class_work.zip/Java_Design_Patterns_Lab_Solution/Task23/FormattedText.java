public interface FormattedText { String render(); }
