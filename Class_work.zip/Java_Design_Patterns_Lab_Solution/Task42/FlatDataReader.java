public interface FlatDataReader { int[] readFlatArray(); }
