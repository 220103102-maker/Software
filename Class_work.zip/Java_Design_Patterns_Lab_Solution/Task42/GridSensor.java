public class GridSensor { private final int[][] grid; public GridSensor(int[][] grid){this.grid=grid;} public int[][] readGrid(){return grid;} }
