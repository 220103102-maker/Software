public class InrBankGateway { public void processRupees(double rupees){System.out.println("Processing INR "+rupees);} }
