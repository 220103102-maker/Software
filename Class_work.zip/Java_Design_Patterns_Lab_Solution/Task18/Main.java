public class Main { public static void main(String[] args){new CurrencyAdapter(new InrBankGateway()).payInUsd(10.0);} }
