public interface UsdPaymentProcessor { void payInUsd(double dollars); }
