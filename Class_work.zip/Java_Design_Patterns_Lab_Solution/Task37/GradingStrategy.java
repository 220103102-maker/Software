public interface GradingStrategy { String evaluate(int score); }
