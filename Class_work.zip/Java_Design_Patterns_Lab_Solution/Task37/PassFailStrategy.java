public class PassFailStrategy implements GradingStrategy { public String evaluate(int s){return s>=50?"PASS":"FAIL";} }
