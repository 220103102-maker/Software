public class LetterGradeStrategy implements GradingStrategy { public String evaluate(int s){return s>=90?"A":s>=75?"B":s>=50?"C":"F";} }
