public class HonorsStrategy implements GradingStrategy { public String evaluate(int s){return s>=85?"DISTINCTION":s>=60?"MERIT":"UNGRADED";} }
