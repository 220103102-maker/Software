public class Main { public static void main(String[] args){ ModernPrinter printer=new PrinterAdapter(new DotMatrixPrinter()); printer.printDocument("Hello"); } }
