public interface ModernPrinter { void printDocument(String text); }
