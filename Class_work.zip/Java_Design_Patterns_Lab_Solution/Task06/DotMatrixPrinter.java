public class DotMatrixPrinter { public void printCharArray(char[] buffer){for(int i=0;i<buffer.length;i++){if(i>0)System.out.print(" ");System.out.print(buffer[i]);}System.out.println();} }
