public class InsertionSortStrategy implements SortStrategy { public void sort(int[] a) { for(int i=1;i<a.length;i++){ int key=a[i],j=i-1; while(j>=0&&a[j]>key){a[j+1]=a[j];j--;} a[j+1]=key; } } }
