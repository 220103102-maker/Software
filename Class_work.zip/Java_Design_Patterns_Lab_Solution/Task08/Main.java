public class Main { public static void main(String[] args){Pizza p=new Jalapenos(new Olives(new ExtraCheese(new Margherita())));System.out.println(p.getDetails());System.out.println(p.getPrice());} }
