public interface Pizza { String getDetails(); int getPrice(); }
