public class Margherita implements Pizza { public String getDetails(){return "Margherita";} public int getPrice(){return 200;} }
