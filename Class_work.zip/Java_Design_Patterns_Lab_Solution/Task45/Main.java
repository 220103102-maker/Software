public class Main { public static void main(String[] args){System.out.println(new ColorAdapter(new RgbColor(255,100,50)).getLuminance());} }
