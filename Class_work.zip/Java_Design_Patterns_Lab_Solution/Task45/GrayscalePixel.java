public interface GrayscalePixel { int getLuminance(); }
