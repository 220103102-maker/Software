public interface ValidationStrategy { boolean isValid(String password); }
