public class NoSpaceValidator implements ValidationStrategy { public boolean isValid(String p){return p!=null&&!p.contains(" ");} }
