public class LengthValidator implements ValidationStrategy { public boolean isValid(String p){return p!=null&&p.length()>=8;} }
