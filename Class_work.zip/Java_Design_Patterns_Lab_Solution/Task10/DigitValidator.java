public class DigitValidator implements ValidationStrategy { public boolean isValid(String p){return p!=null&&p.matches(".*[0-9].*");} }
