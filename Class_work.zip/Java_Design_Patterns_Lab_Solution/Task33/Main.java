public class Main { public static void main(String[] args){LibraryItem b=new BookAdapter(new OldBookEntry("A. Author","Design Patterns",2024));System.out.println(b.getCitation());} }
