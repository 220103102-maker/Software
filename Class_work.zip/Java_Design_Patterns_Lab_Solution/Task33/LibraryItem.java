public interface LibraryItem { String getCitation(); }
