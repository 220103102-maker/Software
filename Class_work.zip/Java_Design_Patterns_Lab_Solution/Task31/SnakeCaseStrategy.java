public class SnakeCaseStrategy implements CaseStrategy { public String convert(String s){return s.trim().toLowerCase().replaceAll("\\s+","_");} }
