public interface CaseStrategy { String convert(String phrase); }
