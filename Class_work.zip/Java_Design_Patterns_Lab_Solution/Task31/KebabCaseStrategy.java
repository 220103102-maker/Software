public class KebabCaseStrategy implements CaseStrategy { public String convert(String s){return s.trim().toLowerCase().replaceAll("\\s+","-");} }
