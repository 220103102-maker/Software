public class Main { public static void main(String[] args){new VlcAdapter(new VlcEngine()).playAudio("song.mp3");} }
