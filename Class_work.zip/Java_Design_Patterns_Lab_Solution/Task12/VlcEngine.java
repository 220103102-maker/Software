public class VlcEngine { public void startPlayback(String filepath,int volume){System.out.println("Playing "+filepath+" at volume "+volume);} }
