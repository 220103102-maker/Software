public interface MediaPlayer { void playAudio(String filename); }
