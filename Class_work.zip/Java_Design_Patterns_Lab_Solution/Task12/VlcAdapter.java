public class VlcAdapter implements MediaPlayer { private final VlcEngine engine; public VlcAdapter(VlcEngine e){engine=e;} public void playAudio(String filename){engine.startPlayback(filename,80);} }
