public class BasicToken implements TokenGenerator { public String generate(String seed){return seed;} }
