public interface TokenGenerator { String generate(String seed); }
